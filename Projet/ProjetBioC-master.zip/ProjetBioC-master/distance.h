// struct distance {

// };
// typedef struct distance DISTANCE;
