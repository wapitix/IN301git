#include <sys/time.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


void  chrono_start();
float chrono_lap();
